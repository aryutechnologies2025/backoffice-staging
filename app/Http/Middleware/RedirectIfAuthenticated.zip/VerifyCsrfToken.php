<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    protected $except = [
        'api/*', // Add this line to exclude all API routes
        'https://backoffice.innerpece.com/api/contact',
        // 'customer-package/latest-update',  // match your route here
    ];
}
